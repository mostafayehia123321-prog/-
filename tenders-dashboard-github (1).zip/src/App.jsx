import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';

function App() {
  const [tenders, setTenders] = useState([
    { title: "مناقصة تنظيف مبنى حكومي", category: "تنظيف", date: "2025-09-25", deadline: "2025-10-10", link: "#" },
    { title: "مناقصة صيانة شبكات الكهرباء", category: "صيانة", date: "2025-09-26", deadline: "2025-10-15", link: "#" },
    { title: "مناقصة خدمات الضيافة لفعالية", category: "ضيافة", date: "2025-09-27", deadline: "2025-10-05", link: "#" },
    { title: "إدارة مرافق لمجمع سكني", category: "إدارة مرافق", date: "2025-09-28", deadline: "2025-10-20", link: "#" }
  ]);

  const exportExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(tenders);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Tenders");
    const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    const data = new Blob([excelBuffer], { type: "application/octet-stream" });
    saveAs(data, "tenders.xlsx");
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">📊 لوحة متابعة المناقصات - قطر</h1>
      <button onClick={exportExcel} className="mb-4 px-4 py-2 bg-blue-600 text-white rounded">📥 تحميل Excel</button>
      <table className="w-full border-collapse bg-white shadow rounded">
        <thead>
          <tr className="bg-gray-200">
            <th className="p-2 border">العنوان</th>
            <th className="p-2 border">الفئة</th>
            <th className="p-2 border">تاريخ النشر</th>
            <th className="p-2 border">تاريخ الإغلاق</th>
            <th className="p-2 border">الرابط</th>
          </tr>
        </thead>
        <tbody>
          {tenders.map((t, i) => (
            <tr key={i} className="text-center">
              <td className="p-2 border">{t.title}</td>
              <td className="p-2 border">{t.category}</td>
              <td className="p-2 border">{t.date}</td>
              <td className="p-2 border">{t.deadline}</td>
              <td className="p-2 border"><a href={t.link} className="text-blue-600">رابط</a></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;